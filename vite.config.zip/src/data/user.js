export const username = "Jaqueline Hirose";

export const user = "Jaqueline Hirose de Oliveira";
