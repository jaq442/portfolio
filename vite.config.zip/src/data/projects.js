export const projects = [
  {
    name: "Projeto 1",
    description: "Atividade recriando landing page com React",
    link: "https://food-app-exercicio.vercel.app/",
  },
  {
    name: "Projeto 2",
    description: "Atividade recriando site com HTML e CSS",
    link:"https://aluraplus-chi-beige.vercel.app/",
  },

];
